import java.io.*;
import java.security.*;
import java.util.*;
import java.util.concurrent.*;
import java.nio.file.*;

/***************************************************/
/* CS-350 Fall 2021 - Homework 7 - Code Solution   */
/* Author: Renato Mancuso (BU)                     */
/*                                                 */
/* Description: This class implements the logic of */
/*   a super-entity, called Pirate that uses the   */
/*   Dispatcher class multiple times to create     */
/*   two stages of computation. In the first stage */
/*   the system cracks simple hashes, while in the */
/*   second, compound hashes are cracked.          */
/*                                                 */
/***************************************************/

public class Pirate {

    String fileName;
    int numCPUs;
    int timeoutMillis;
	String cipherName;
    Dispatcher dispatcher;

	boolean noMoreWork;		// boolean to signal if there is no more work to be done (all hashes have been cracked)
	String cipherText;
	String answer;

	/* Array of all the keys gathered from rounds of processing */
	ArrayList<Integer> nums;

    /* Queue for inputs to be processed */
    LinkedList<WorkUnit> workQueue;

    /* Queue for processed outputs */
    LinkedList<WorkUnit> resQueue;

    /* Mutex to protect input queue */   
    Semaphore wqMutex;
    
    /* Mutex to protect output queue */
    Semaphore rsMutex;

    
    public Pirate (String fileName, int N, int timeout, String cipherName) {
		this.fileName = fileName;
		this.numCPUs = N;
		this.timeoutMillis = timeout;
		this.cipherName = cipherName;
		this.noMoreWork = false;
		this.cipherText = "";
		this.answer = "";

		/* Now build the other data structures */
		nums = new ArrayList<>();

		workQueue = new LinkedList<>();
		resQueue = new LinkedList<>();

		wqMutex = new Semaphore(1);
		rsMutex = new Semaphore(1);
	
		/* Construct the dispatcher which will also start the worker threads */
        this.dispatcher = new Dispatcher(workQueue, resQueue, wqMutex, rsMutex, N, timeout);	
    }

    private void __initWorkQueue() throws InterruptedException {
        /* The fileName parameter contains the full path to the input file */
        Path inputFile = Paths.get(fileName);

		/* Attempt to open the input file, if it exists */
        if (Files.exists(inputFile)) {

	    	/* It appears to exists, so open file */
            File fHandle = inputFile.toFile();
            
            /* Use a buffered reader to be a bit faster on the I/O */
            try (BufferedReader in = new BufferedReader(new FileReader(fHandle))) {

                String line;
		
				/* Pass each line read in input to the dehasher */
                while((line = in.readLine()) != null){
		    		WorkUnit work = new WorkUnit(line);
		    		dispatcher.addWork(work);
                }

			} catch (FileNotFoundException e) {
                System.err.println("Input file does not exist.");
                e.printStackTrace();
            } catch (IOException e) {
                System.err.println("Unable to open input file for read operation.");
                e.printStackTrace();
            }	    
	    
        } else {
            System.err.println("Input file does not exist. Exiting.");        	
        }
	
    }

    private void __prepareCompoundWork() throws InterruptedException {
		/* This function will execute when no pending work exists. But
		 * as it goes along, worker threads might start crunching
		 * data. Hence, copy over all the result so far. */

		ArrayList<Integer> L = new ArrayList<>();
		ArrayList<String> uncracked = new ArrayList<>();
	
		for (WorkUnit w : resQueue) {
	    	String res = w.getResult();
	    
	    	if (res != null) {
				L.add(w.getKey()); 			// needs "key" not full result
				nums.add(w.getKey());
		
				/* We might as well print this first round of results already */
				//System.out.println(res);
	    	} else {
				/* Just to be on the safe side, in case we get the same unhashed work from resQueue
				 * only add the work, if it hasn't been cracked and hasn't been already added to queue */
				if (!uncracked.contains(w.getHash())) {
					uncracked.add(w.getHash());
				}
	    	}
		}

		/* Done splitting result -- we can clean up the result queue */
		resQueue.clear();

		/* Sort list L of integers */
		Collections.sort(L);

		/* Check if there is actually any uncracked hashes and flag or create more work accordingly */
		if (uncracked.isEmpty()) {
			noMoreWork = true;
		} else {
			/* Possibly the worst way of doing this. Generate all the
			 * possible tuples of the form <a, b, hash> to be cracked. The
			 * work queue might explode after this. A work-queue pruning
			 * strategy is required to meet some reasonable timing
			 * constraints. */
			int len = L.size();
			for (int i = 0; i < len-1; ++i) {
	    		for (int j = i + 1; j < len; ++j) {
					for (String h : uncracked) {
		    			WorkUnit work = new WorkUnit(h, L.get(i), L.get(j));
		    			dispatcher.addWork(work);
					}
	    		}
			}
		}

    }

    private void __postProcessResult() {
		Collections.sort(nums);

		/* Attempt to open cipher file and construct the ciphertext */
		try {
            File cipherFile = new File(cipherName);
            Scanner lines = new Scanner(cipherFile).useDelimiter("\n");

            while (lines.hasNext()) {
                cipherText += lines.next() + "\n";
            }

            lines.close();
        } catch (FileNotFoundException e) {
            System.out.println("Cipher file not found");
            e.printStackTrace();
        }

		for (Integer num : nums) {
			answer += cipherText.charAt(num);
		}

		System.out.println(answer);

    }
    
    public void findTreasure () throws InterruptedException {

		/* Read the input file and initialize the input queue */
	
		__initWorkQueue();

		/* Work loop - we process over the current work, then we take the results and generate more work */

		while(!noMoreWork) {
			/* Dispatch work and wait for completion of current stage */
			dispatcher.dispatch();

			rsMutex.acquire();	
			/* We have the result. Generate the new work queue to crack compound hashes */
			__prepareCompoundWork();
			rsMutex.release();
		}

		/* Take the offsets gathered and decode the cipher
		 * semaphores aren't needed here since the method doesn't touch any shared resources
		 * only Pirate has access to the array of offsets */

		__postProcessResult();

		/* Done! Terminate the dispatcher (and any worker thread with that) */
		dispatcher.terminate();
	
    }

    public static void main(String[] args) throws InterruptedException {
		/* Read path of input file */       
        String inputFile = args[0];

		/* Read number of available CPUs */
		int N = Integer.parseInt(args[1]);

		/* Read in timeout */
		int timeoutMillis = Integer.parseInt(args[2]);

		String cipherFile = args[3];

		/* Construct the dispatcher with all the necessary parameters */
        Pirate thePirate = new Pirate(inputFile, N, timeoutMillis, cipherFile);

		/* Start the work */
        thePirate.findTreasure();
    }
}

/* END -- Q1BSR1QgUmVuYXRvIE1hbmN1c28= */
